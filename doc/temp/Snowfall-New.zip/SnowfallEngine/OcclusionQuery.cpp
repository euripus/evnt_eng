#include "stdafx.h"

#include "OcclusionQuery.h"

OcclusionQuery::OcclusionQuery() {}

OcclusionQuery::~OcclusionQuery() {}
