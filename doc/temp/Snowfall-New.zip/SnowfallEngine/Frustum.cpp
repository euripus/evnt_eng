#include "stdafx.h"

#include "Frustum.h"

Frustum::Frustum() {}

Frustum::~Frustum() {}
