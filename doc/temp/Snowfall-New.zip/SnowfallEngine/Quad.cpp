#include "stdafx.h"

Quad2D::Quad2D(IQuad2D & quad) : Position(quad.Position), Size(quad.Size) {}