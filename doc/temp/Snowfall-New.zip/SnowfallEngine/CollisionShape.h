#pragma once
class CollisionShape
{
public:
    CollisionShape();
    ~CollisionShape();
};
