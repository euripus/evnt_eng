#pragma once

class IGLResource
{
public:
    virtual void Destroy() = 0;
};