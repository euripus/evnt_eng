#pragma once
#include "GLResource.h"
#include <gl\glew.h>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include "export.h"

class Shader : public IGLResource
{
public:
    SNOWFALLENGINE_API              Shader() {}
    SNOWFALLENGINE_API              Shader(std::string src, std::set<std::string> defines);
    inline GLuint                   GetID() const { return m_id; }
    inline std::string              GetShaderInfoLog() { return m_infoLog; }
    inline std::vector<std::string> GetShaderStageInfoLogs() { return m_shaderInfoLogs; }
    inline bool                     IsCompileSuccess() { return m_compileSuccess; }
    SNOWFALLENGINE_API virtual void Destroy() override;

private:
    bool                     m_compileSuccess = false;
    std::string              m_infoLog;
    std::vector<std::string> m_shaderInfoLogs;
    GLuint                   m_id = 0;
};
