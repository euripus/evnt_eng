#include "ResourceStreamingSystem.h"
#include "stdafx.h"
