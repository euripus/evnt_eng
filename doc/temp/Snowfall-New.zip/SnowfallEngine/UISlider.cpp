#include "UISlider.h"
#include "stdafx.h"
