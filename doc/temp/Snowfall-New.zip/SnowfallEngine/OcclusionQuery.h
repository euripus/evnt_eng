#pragma once
#include "export.h"

class SNOWFALLENGINE_API OcclusionQuery
{
public:
    OcclusionQuery();
    ~OcclusionQuery();
};
