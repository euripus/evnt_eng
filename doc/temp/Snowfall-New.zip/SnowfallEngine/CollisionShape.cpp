#include "stdafx.h"

#include "CollisionShape.h"

CollisionShape::CollisionShape() {}

CollisionShape::~CollisionShape() {}
