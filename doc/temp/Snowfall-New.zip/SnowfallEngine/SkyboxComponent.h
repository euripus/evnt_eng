#pragma once
#include "ECS.h"
#include "TextureAsset.h"

class SkyboxComponent : public Component
{
public:
    TextureAsset * Cubemap;
    bool           Enabled;

    RenderTargetAsset * renderTarget;
};