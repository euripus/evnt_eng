#pragma once

#include <Windows.h>

#include "export.h"

#define GLM_FORCE_SSE42
#define GLM_FORCE_ALIGNED

#include "ECS.h"
#include "Snowfall.h"
#include "UUID.h"
#include <glm/glm.hpp>

#undef min