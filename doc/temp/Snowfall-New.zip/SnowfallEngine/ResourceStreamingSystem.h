#pragma once
class ResourceStreamingSystem
{};
