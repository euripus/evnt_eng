//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Win32AppResource.rc
//
#define IDD_DEVICE_TYPE_SELECTION_DIALOG 101
#define IDB_OPENGL_LOGO 102
#define IDB_VULKAN_LOGO 103
#define IDB_DIRECTX11_LOGO 104
#define IDB_DIRECTX12_LOGO 105
#define ID_VULKAN 1001
#define ID_OPENGL 1002
#define ID_DIRECT3D11 1003
#define ID_DIRECT3D12 1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE 106
#define _APS_NEXT_COMMAND_VALUE 40001
#define _APS_NEXT_CONTROL_VALUE 1005
#define _APS_NEXT_SYMED_VALUE 101
#endif
#endif
