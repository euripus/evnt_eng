#ifndef COMMON_H
#define COMMON_H

#define NUM_UNIQUE_TEXTURES 10

#endif
